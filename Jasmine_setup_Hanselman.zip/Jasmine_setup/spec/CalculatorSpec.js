
describe("Test add() method", function() {
 	var calc;
    //This will be called before running each spec
    beforeEach(function() {
        calc = new Calculator(); //Create a calculator object to call our math operations
    });

    /*
    *  Example Test Case for Addition Operation
    */
   it("Check addition, two positive values", function() {

        expect( calc.add(1,2) ).toEqual(3);
    });

   it("Check addition, two negative values", function() {

        expect( calc.add(-7,-5) ).toEqual(-12);
    });

    it("check subtraction, two positive values", function(){
        expect( calc.sub(1,2) ).toEqual(-1);
    });

    it("check subtraction, two negative values", function(){
        expect( calc.sub(-11,-2) ).toEqual(-9);
    });

    it("check multiplication, two positive values", function(){
        expect( calc.multiply(3,4) ).toEqual(12);
    });

    it("check multiplication, two negative values", function(){
        expect( calc.multiply(-10,-5) ).toEqual(50);
    });

    it("check division, two positive values", function(){
        expect( calc.divide(4,2) ).toEqual(2);
    });

    it("check division, two negative values", function(){
        expect( calc.divide(-16,-8) ).toEqual(2);
    });
});

/*
* Create a new test suit with two new test cases for sub() method
*/

/*
* Create a new test suit with two new test cases for multiply() method
*/

/*
* Create a new test suit with two new test cases for divide() method
*/
